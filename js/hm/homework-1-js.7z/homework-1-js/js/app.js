// №1 і№2 пункти
// let greetings = 'hello'; 
// greetings ='owu';
// let school = 'owu'; 
// school='hello';
// let web ='com'; 
// web='ua';
// let country ='ua'; 
// country='1';
// let x1 ='1';
// x1='com';
// let x2 ='10';
// x2='123';
// let x3 ='-999';
// x3='3.14';
// let x4 ='123';
// x4='-999';
// let p ='3.14';
// p='10'

// console.log(greetings); 
// console.log(school);
// console.log(web);
// console.log(country);
// console.log(x1);
// console.log(x2);
// console.log(x3);
// console.log(x4);
// console.log(p);   
// alert(greetings);
//  alert(school);
//  alert (web);
//  alert (country);
//   alert (x1);
//   alert (x2);
//   alert (x3);
//   alert(x4);
//   alert( p );
// document.write(greetings  +  school + web + country + x1 + x2 + x3 + x4 + p)



// №3

// let x = 'Hello';
// let name = 'Користувач';
// let age = 'Введіть  ваш  вік'; 
// console.log(name);
// console.log(x); 
// console.log(age);

// alert(name); 
// alert(age);
// alert(x);

//4
// let name = prompt('Your name'); 
// console.log(name);
// alert(name);
// document.write(name) 

// let lastName = prompt('Your Last Name')
// console.log(lastName);
// alert(lastName);
// document.write(lastName); 

// let age = prompt('Your age')
// console.log(age);
// alert(age);
// document.write(age);

//5
// let a= '100';
// console.log(a)
// console.log( typeof a); 
// document.write(a); 

// let b= '100'
// console.log(b)
// console.log( typeof b); 
// document.write(b);

// let bullian = true;
// console.log(bullian)
// console.log( typeof bullian); 
// document.write(bullian);



//№6
// console.log( 5 < 6 ); 
// console.log( 5 > 6 );
// console.log( 5 !== 6);
// console.log( 5 === 6);

// console.log( 10 === 10); 
// console.log( 10 == 10); 


// console.log( 10 != 10 );
// console.log( 10 > 10 );
// console.log( 10 < 10 ); 

// console.log(123 == 123);
// console.log(123 > '123'); 




















