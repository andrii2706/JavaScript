// світлофор для машин через  switch

// let color = prompt('Введіть колір');
// let car = confirm('Машини є надорозі');

// switch ( color){
//     case 'green':
//     case true: 
//     alert('Їдь');
//     break;
//     case 'green': 
//     case false:
//     alert('Почекай коли всі закінчать рух');
//     break; 
//     case 'yellow': 
//     case true: 
//     alert('Зверни увагу на пішоходів'); 
//     break;
//     case 'yellow':
//     case false:
//     alert('Підготуся до руху');
//     break;
//     case 'red':
//     case false: 
//     alert('Стій нерухайся');
//     break; 
//     case 'red':
//     case true:
//     alert('СТІЙ!');        
//     default:
//     console.log('1234567890')
//     break;
// }


// світлофор  через  if else 

// let color = prompt('Введіть колір');
// let car = confirm('Машини є надорозі');

// if (color === 'зелений' && car){
//     alert('Їдь');
// }else if(color === 'зелений' && !car){
//     alert('Зачекай коли проїдуть порушники');
// }else if( color === 'green' && car){
//         alert('їдь')
// }else if(color === 'green' && !car){
//     alert('Зачекай коли проїдуть порушники')
// }else if(color === 'yellow'  && car){
//     alert('Все одно чекай')
// }else if(color === 'yellow' && !car){
//     alert('Зачекай')
// }else if(color === 'жовтий'  && car){
//     alert('Все одно чекай')
// }else if(color === 'жовтий' && !car){
//     alert('Зачекай')
// }else if(color === 'червоний'  && car){
//     alert('Стій, все-одно рано')
// }else if(color === 'червоний'  && !car){
//     alert('Стій!')
// }else if(color === 'red'  && car){
//     alert('Стій, все-одно рано')
// }else if(color === 'red'  && !car){
//     alert('Стій!')
// } 




// вибір чисел
// let a1 = +prompt('Введіть перше число');
// let a2 = +prompt('Введіть  друге число');
// let a3 = +prompt('Введіть третє  число'); 

// if(a1 > a2 &&  a1 > a3){
//     console.log( a1, a2, a3 )
// }else if (a1< a2 && a2>a3){
//     console.log( a2, a1, a3 );
// }else if (a1< a2 && a2>a3){
//     console.log( a2, a3, a2 );
// }else if (a1< a2 && a2>a3){
//     console.log( a2, a3, a1 );
// }else if( a1< a2 &&a2< a3){
//     console.log( a3, a2, a1 )
// }









// }else if( a2 === a3 === a1){
// }else if( a1 === a2 === a3){
//     console.log(a1, a2, a3  );
//     console.log(a2, a3, a1)
// }else if(a1 != a2 != a3){
//     console.log(a1, a2, a3)


